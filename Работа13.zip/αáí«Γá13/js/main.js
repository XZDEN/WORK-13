new Vue({
    el: '#app',
    data: {
        show: true,
        cars: [
            {model: "BMW", speed: 250.8},
            {model: "Audi", speed: 240.21},
            {model: "Mercedes-Benz AMG", speed: 350.4},
            {model: "Ford", speed: 160.5},           
        ]
    },
    methods: {

    }
})